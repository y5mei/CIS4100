# Assignment-4 Serverless
## GCP fucntions

1. A storage "cis4010-ymei" has been created already
2. A archive file storage "cis4010-ymei-log" has been created already as well
3. When a user uploaded a file to the cis4010-ymei storage, the serverless function will be triggered, the uploaded file will be copy to the "cis4010-ymei-log" storage, a log file will then be created as well under the Archive folder.


# AWS lambda

1. A S3 instance "cis4010-ymei" has been created already
2. A archive S3 instance "cis4010-ymei-backup" has been crated already as well
3. When a user uploaded a file to the "cis4010-ymei" storage, the serverless function will be triggered, the uploaded file will be copy to the "cis4010-ymei-backup" storage, a log file will then be created as well under the logfile folder.


